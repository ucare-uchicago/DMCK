/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

package org.apache.cassandra.locator;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;

import org.apache.cassandra.exceptions.ConfigurationException;
import org.apache.cassandra.service.StorageService;
import org.junit.Test;

import org.apache.cassandra.utils.FBUtilities;

public class DynamicEndpointSnitchTest
{
    @Test
    public void testSnitch() throws InterruptedException, IOException, ConfigurationException
    {
        // do this because SS needs to be initialized before DES can work properly.
        StorageService.instance.initClient();
        int sleeptime = 150;
        SimpleSnitch ss = new SimpleSnitch();
        DynamicEndpointSnitch dsnitch = new DynamicEndpointSnitch(ss, String.valueOf(ss.hashCode()));
        InetAddress self = FBUtilities.getBroadcastAddress();
        ArrayList<InetAddress> order = new ArrayList<InetAddress>();
        InetAddress host1 = InetAddress.getByName("127.0.0.4");
        InetAddress host2 = InetAddress.getByName("127.0.0.2");
        InetAddress host3 = InetAddress.getByName("127.0.0.3");

        // first, make all hosts equal
        for (int i = 0; i < 5; i++)
        {
            dsnitch.receiveTiming(host1, 1L);
            dsnitch.receiveTiming(host2, 1L);
            dsnitch.receiveTiming(host3, 1L);
        }

        Thread.sleep(sleeptime);

        order.add(host1);
        order.add(host2);
        order.add(host3);
        assert dsnitch.getSortedListByProximity(self, order).equals(order);

        // make host1 a little worse
        dsnitch.receiveTiming(host1, 2L);
        dsnitch.receiveTiming(host2, 1L);
        dsnitch.receiveTiming(host3, 1L);
        Thread.sleep(sleeptime);

        order.clear();
        order.add(host2);
        order.add(host3);
        order.add(host1);
        assert dsnitch.getSortedListByProximity(self, order).equals(order);

        // make host2 as bad as host1
        dsnitch.receiveTiming(host2, 2L);
        dsnitch.receiveTiming(host1, 1L);
        dsnitch.receiveTiming(host3, 1L);
        Thread.sleep(sleeptime);

        order.clear();
        order.add(host3);
        order.add(host1);
        order.add(host2);
        assert dsnitch.getSortedListByProximity(self, order).equals(order);

        // make host3 the worst
        for (int i = 0; i < 2; i++)
        {
            dsnitch.receiveTiming(host1, 1L);
            dsnitch.receiveTiming(host2, 1L);
            dsnitch.receiveTiming(host3, 2L);
        }
        Thread.sleep(sleeptime);

        order.clear();
        order.add(host1);
        order.add(host2);
        order.add(host3);
        assert dsnitch.getSortedListByProximity(self, order).equals(order);

        // make host3 equal to the others
        for (int i = 0; i < 2; i++)
        {
            dsnitch.receiveTiming(host1, 1L);
            dsnitch.receiveTiming(host2, 1L);
            dsnitch.receiveTiming(host3, 1L);
        }
        Thread.sleep(sleeptime);

        order.clear();
        order.add(host1);
        order.add(host2);
        order.add(host3);
        assert dsnitch.getSortedListByProximity(self, order).equals(order);
    }
}
