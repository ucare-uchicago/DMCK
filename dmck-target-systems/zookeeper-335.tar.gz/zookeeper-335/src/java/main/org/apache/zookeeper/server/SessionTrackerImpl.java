/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.zookeeper.server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import org.apache.zookeeper.KeeperException;

/**
 * This is a full featured SessionTracker. It tracks session in grouped by tick
 * interval. It always rounds up the tick interval to provide a sort of grace
 * period. Sessions are thus expired in batches made up of sessions that expire
 * in a given interval.
 */
public class SessionTrackerImpl extends Thread implements SessionTracker {
    private static final Logger LOG = Logger.getLogger(SessionTrackerImpl.class);

    HashMap<Long, Session> sessionsById = new HashMap<Long, Session>();

    HashMap<Long, SessionSet> sessionSets = new HashMap<Long, SessionSet>();

    ConcurrentHashMap<Long, Integer> sessionsWithTimeout;
    long nextSessionId = 0;
    long serverId;
    long nextExpirationTime;

    int expirationInterval;

    public static class Session {
        Session(long sessionId, long expireTime) {
            this.sessionId = sessionId;
            this.tickTime = expireTime;
        }

        long tickTime;

        long sessionId;
    }

    public static long initializeNextSession(long id) {
        long nextSid = 0;
//        nextSid = (System.currentTimeMillis() << 24) >> 8; // DMCK: modified to remove non-determinism and replaced with some init
        nextSid = 1396211756494L;
        nextSid =  nextSid | (id <<56);
        return nextSid;
    }

    static class SessionSet {
        long expireTime;

        HashSet<Session> sessions = new HashSet<Session>();
    }

    SessionExpirer expirer;

    private long roundToInterval(long time) {
        // We give a one interval grace period
        return (time / expirationInterval + 1) * expirationInterval;
    }

    public SessionTrackerImpl(SessionExpirer expirer,
            ConcurrentHashMap<Long, Integer> sessionsWithTimeout, int tickTime, long sid) {
        super("SessionTracker");
        this.expirer = expirer;
        this.expirationInterval = tickTime;
        this.sessionsWithTimeout = sessionsWithTimeout;
        nextExpirationTime = roundToInterval(System.currentTimeMillis());
        this.serverId = sid;
        this.nextSessionId = initializeNextSession(sid);
        for (long id : sessionsWithTimeout.keySet()) {
            addSession(id, sessionsWithTimeout.get(id));
        }
        start();
    }

    volatile boolean running = true;

    volatile long currentTime;

    @Override
    synchronized public String toString() {
        StringBuffer sb = new StringBuffer("Session Sets ("
                + sessionSets.size() + "):\n");
        ArrayList<Long> keys = new ArrayList<Long>(sessionSets.keySet());
        Collections.sort(keys);
        for (long time : keys) {
            sb.append(sessionSets.get(time).sessions.size() + " expire at "
                    + new Date(time) + ":\n");
            for (Session s : sessionSets.get(time).sessions) {
                sb.append("\t" + s.sessionId + "\n");
            }
        }
        return sb.toString();
    }

    @Override
    synchronized public void run() {
        try {
            while (running) {
                currentTime = System.currentTimeMillis();
                if (nextExpirationTime > currentTime) {
                    this.wait(nextExpirationTime - currentTime);
                    continue;
                }
                SessionSet set;
                set = sessionSets.remove(nextExpirationTime);
                if (set != null) {
                    for (Session s : set.sessions) {
                        sessionsById.remove(s.sessionId);
                        LOG.info("Expiring session 0x"
                                + Long.toHexString(s.sessionId));
                        expirer.expire(s.sessionId);
                    }
                }
                nextExpirationTime += expirationInterval;
            }
        } catch (InterruptedException e) {
            LOG.error("Unexpected interruption", e);
        }
        LOG.info("SessionTrackerImpl exited loop!");
    }

    synchronized public boolean touchSession(long sessionId, int timeout) {
        ZooTrace.logTraceMessage(LOG,
                                 ZooTrace.CLIENT_PING_TRACE_MASK,
                                 "SessionTrackerImpl --- Touch session: 0x"
                + Long.toHexString(sessionId) + " with timeout " + timeout);
        Session s = sessionsById.get(sessionId);
        if (s == null) {
            return false;
        }
        long expireTime = roundToInterval(System.currentTimeMillis() + timeout);
        if (s.tickTime >= expireTime) {
            // Nothing needs to be done
            return true;
        }
        SessionSet set = sessionSets.get(s.tickTime);
        if (set != null) {
            set.sessions.remove(s);
        }
        s.tickTime = expireTime;
        set = sessionSets.get(s.tickTime);
        if (set == null) {
            set = new SessionSet();
            set.expireTime = expireTime;
            sessionSets.put(expireTime, set);
        }
        set.sessions.add(s);
        return true;
    }

    synchronized public void removeSession(long sessionId) {
        Session s = sessionsById.remove(sessionId);
        sessionsWithTimeout.remove(sessionId);
        ZooTrace.logTraceMessage(LOG, ZooTrace.SESSION_TRACE_MASK,
                "SessionTrackerImpl --- Removing session 0x"
                + Long.toHexString(sessionId));
        if (s != null) {
            sessionSets.get(s.tickTime).sessions.remove(s);
        }
    }

    public void shutdown() {
        running = false;
        ZooTrace.logTraceMessage(LOG, ZooTrace.getTextTraceLevel(),
                                 "Shutdown SessionTrackerImpl!");
    }

   
    synchronized public long createSession(int sessionTimeout) {
        addSession(nextSessionId, sessionTimeout);
        return nextSessionId++;
    }

    synchronized public void addSession(long id, int sessionTimeout) {
        sessionsWithTimeout.put(id, sessionTimeout);
        if (sessionsById.get(id) == null) {
            Session s = new Session(id, 0);
            sessionsById.put(id, s);
            ZooTrace.logTraceMessage(LOG, ZooTrace.SESSION_TRACE_MASK,
                    "SessionTrackerImpl --- Adding session 0x" 
                    + Long.toHexString(id) + " " + sessionTimeout);
        } else {
            ZooTrace.logTraceMessage(LOG, ZooTrace.SESSION_TRACE_MASK,
                    "SessionTrackerImpl --- Existing session 0x" 
                    + Long.toHexString(id) + " " + sessionTimeout);
        }
        touchSession(id, sessionTimeout);
    }

    public void checkSession(long sessionId) throws KeeperException.SessionExpiredException {
        if (sessionsById.get(sessionId) == null) {
            throw new KeeperException.SessionExpiredException();
        }
    }
}
