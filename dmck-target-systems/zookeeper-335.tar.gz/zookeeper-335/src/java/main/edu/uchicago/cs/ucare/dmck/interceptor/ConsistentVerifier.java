package edu.uchicago.cs.ucare.dmck.interceptor;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.zookeeper.server.DataNode;
import org.apache.zookeeper.server.DataTree;
import org.apache.zookeeper.server.persistence.FileTxnSnapLog;

public class ConsistentVerifier {

	private static final Logger LOG = Logger.getLogger(ConsistentVerifier.class);
	
	static String workingDir;
    static String path;
    static File[] dataDir;
    static File[] dataLogDir;
    static int numNode;
	
	public static void main(String[] args) {
		if(args.length != 4){
			System.out.println("Usage: please specify <working_dir> <num_node> <key> <String_of_node_aliveness>");
			System.exit(1);
		}
		workingDir = args[0];
        numNode = Integer.parseInt(args[1]);
        dataDir = new File[numNode];
        dataLogDir = new File[numNode];
        for (int i = 0; i < numNode; ++i) {
            dataDir[i] = new File(workingDir + "/data/zk" + i);
            dataLogDir[i] = new File(workingDir + "/log/zk" + i);
        }
        path = args[2];
        String[] isNodeAlive = args[3].split(",");
        
        getValues(isNodeAlive);
	}
	
	public static void getValues(String[] isNodeAlive){
        String[] values = new String[numNode];
        HashMap<Long, Integer> sessions = new HashMap<Long, Integer>();
        for (int i = 0; i < numNode; ++i) {
        	if(isNodeAlive[i].equals("1")){
	        	FileTxnSnapLog txnLog = new FileTxnSnapLog(dataLogDir[i], dataDir[i]);
	        	DataTree dt = new DataTree();
	        	try {
	                txnLog.restore(dt, sessions, null);
	            } catch (IOException e) {
	                values[i] = "-exception-";
	                continue;
	            }
	            DataNode node = dt.getNode(path);
	            if (node != null) {
	                values[i] = new String(node.data);
	            } else {
	                values[i] = "-null-";
	            }
        	} else {
        		values[i] = "-dead-";
        	}
        }
        writeResult(values);
	}
	
	public static void writeResult(String[] content){
		String s = "";
		for(int c = 0; c<content.length ; c++){
			s += c + "=" + content[c] + "\n";
		}

		try{
			PrintWriter writer = new PrintWriter(workingDir + "/temp-verify", "UTF-8");
			writer.println(s);
			writer.close();
		} catch (Exception e){
			LOG.error("ERROR in writing temp-verify result.");
		}
	}

}
