package edu.uchicago.cs.ucare.dmck.interceptor;

import org.apache.jute.BinaryInputArchive;
import org.apache.jute.Record;
import org.apache.log4j.Logger;
import org.apache.zookeeper.ZooDefs.OpCode;
import org.apache.zookeeper.server.quorum.Leader;
import org.apache.zookeeper.server.quorum.QuorumPacket;
import org.apache.zookeeper.server.quorum.Vote;
import org.apache.zookeeper.server.DataTree;
import org.apache.zookeeper.server.Request;
import org.apache.zookeeper.server.util.SerializeUtils;
import org.apache.zookeeper.txn.CreateTxn;
import org.apache.zookeeper.txn.TxnHeader;

import java.io.*;
import java.nio.charset.Charset;
import java.util.HashMap;

public class InterceptionLayer {
	private static final Logger LOG = Logger.getLogger(InterceptionLayer.class);
	
	private static String ipcDir = "/tmp/ipc";
	
	public static void interceptLEEvent(long sender, long recv, int state, long leader, long zxid, long epoch){
    	// for this simulation, we don't exercise local events
		if(sender != recv){
			long eventId = getHashId(sender, recv, state, leader, zxid, epoch);
			
			String filename = "zkLE-" + eventId + "-" + getTimestamp();
			
			String content = "";
			content += "sender=" + sender + "\n";
			content += "recv=" + recv + "\n";
			content += "state=" + state + "\n";
			content += "leader=" + leader + "\n";
			content += "zxid=" + zxid + "\n";
			content += "epoch=" + epoch + "\n";
			content += "eventType=" + 0 + "\n"; // eventType=0 --> Leader Election packet
			content += "eventId=" + eventId + "\n";
			
			writePacketToFile(filename, content);
			
			LOG.info("[DMCK] Intercept a LE message event. sender: " + sender + " recv: " + recv + " state: " + 
					state + " leader: " + leader + " zxid: " + zxid + " epoch: " + epoch + 
					" filename: " + ipcDir + "/" + filename);
			
			commitFile(filename);
			waitForAck(filename);
		}
	}
	
	public static void interceptSnapshotEvent(long sender, long recv, int msgType){
    	// for this simulation, we don't exercise local events
		if(sender != recv){
			long eventId = getHashId(sender, recv, msgType);
			
			String filename = "zkSnapshot-" + eventId + "-" + getTimestamp();
			
			String content = "";
			content += "sender=" + sender + "\n";
			content += "recv=" + recv + "\n";
			content += "eventType=" + msgType + "\n"; // based on Leader.java definition
			content += "eventId=" + eventId + "\n";
			
			writePacketToFile(filename, content);
			
			LOG.info("[DMCK] Intercept a Snapshot message event. sender: " + sender + " recv: " + recv + 
					" msgType: " + msgType + " filename: " + ipcDir + "/" + filename);
			
			commitFile(filename);
			waitForAck(filename);
		}
	}
	
	public static void interceptZABEvent(QuorumPacket packet, long leader, int port){
		if(packet.getType() == Leader.PROPOSAL){
			try{
	    		TxnHeader hdr = new TxnHeader();
	            BinaryInputArchive ia = BinaryInputArchive
	                    .getArchive(new ByteArrayInputStream(packet.getData()));
	            Record txn = SerializeUtils.deserializeTxn(ia, hdr);
	            String keyvalue = "";
	            if(txn instanceof CreateTxn){
	            	CreateTxn temp = (CreateTxn) txn;
	            	String value = new String(temp.getData(), Charset.forName("UTF-8"));
	            	keyvalue = temp.getPath() + "-" + value;
	            	
	            	long eventId = getHashId(leader, packet.getType(), value);
	    			
	    			String filename = "zkZAB-" + eventId + "-" + (port + getTimestamp());
	    			String content = "";
	    			content += "sender=" + leader + "\n";
	    			content += "eventType=" + packet.getType() + "\n";
	    			content += "key=" + temp.getPath() + "\n";
	    			content += "value=" + value + "\n";
	    			content += "port=" + port + "\n";
	    			content += "eventId=" + eventId + "\n";
	    				    			
	    			writePacketToFile(filename, content);
	    			
	    			LOG.info("[DMCK] intercept a CreateTxn packet: leader=" + leader + " type=" + packet.getType() + 
		        			" with key-value=" + keyvalue + " filename=" + filename);

	    			commitFile(filename);
	    			waitForAck(filename);
	            }
			} catch (IOException ex){
				LOG.error("[DMCK] Error when intercepting ZAB event: " + ex.toString());
			}
    	} else if(packet.getType() == Leader.UPTODATE){
    		long eventId = getHashId(leader, packet.getType());
			
			String filename = "zkUpToDate-" + port + eventId + "-" + getTimestamp();
			
			String content = "";
			content += "sender=" + leader + "\n";
			content += "port=" + port + "\n";
			content += "eventType=" + packet.getType() + "\n"; // based on Leader.java definition
			content += "eventId=" + eventId + "\n";
			
			writePacketToFile(filename, content);

    		LOG.info("[DMCK] Intercept UpToDate Msg-" + packet.getType() + " from leader-" + leader + " send to follower port-" + port);
    		
    		// to make sure that UPTODATE msg arrived after Follower inform its port to DMCK
			try{
				Thread.sleep(400);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    		
			commitFile(filename);
			waitForAck(filename);
    	}
	}
	
	public static void interceptDiskWrite(Request request, long nodeId){
		if(request.type == OpCode.create){
			long eventId = getHashId(nodeId, request.type);
			
			String filename = "zkDiskWrite-" + eventId + "-" + getTimestamp();
			String content = "";
			content += "nodeId=" + nodeId + "\n";
			content += "eventType=" + request.type + "\n";
			content += "eventId=" + eventId + "\n";
				    			
			writePacketToFile(filename, content);
			
	        LOG.info("[DMCK] intercept a disk write at node=" + nodeId);
	        
	        commitFile(filename);
	        waitForAck(filename);
        } 
	}
	
	public static void interceptSnapshotLocalEvent(long nodeId){
		String filename = "zkSnapshotLocalEvent-" + nodeId + "-" + getTimestamp();
		String content = "";
		content += "nodeId=" + nodeId + "\n";
		
		writePacketToFile(filename, content);
		
        LOG.info("[DMCK] intercept a snapshot writing at node=" + nodeId);
        
        commitFile(filename);
        waitForAck(filename);
	}
	
	public static void notifyFollowerPort(long nodeId, int port){
		String filename = "zkNotifyFollowerPort-" + nodeId;
		
		String content = "";
		content += "nodeId=" + nodeId + "\n";
		content += "port=" + port + "\n";
		
		writePacketToFile(filename, content);
		
		LOG.info("[DMCK] Intercept a state update in node: " + nodeId + " port: " + port + 
				" filename: " + ipcDir + "/" + filename);
		
		commitFile(filename);
	}
	
	public static void notifySnapshotPersistentState(DataTree dataTree, long nodeId){
		long hashcode = calculateHashCodeForDataTree(dataTree);
		
		String filename = "zkPersistentState-" + nodeId + hashcode + "-" + getTimestamp();
		String content = "";
		content += "nodeId=" + nodeId + "\n";
		content += "hashcode=" + hashcode + "\n";
		
		writePacketToFile(filename, content);
		
        LOG.info("[DMCK] inform snapshot persistent state at node=" + nodeId + " hashcode=" + hashcode);
        
        commitFile(filename);
	}
	
	public static void notifyPersistentState(Request request, long nodeId){
		if(request.type == OpCode.create){
			long hashcode = calculateHashCodeForRequest(request);
			
			String filename = "zkPersistentState-" + nodeId + hashcode + "-" + getTimestamp();
			String content = "";
			content += "nodeId=" + nodeId + "\n";
			content += "hashcode=" + hashcode + "\n";
			
			writePacketToFile(filename, content);
			
	        LOG.info("[DMCK] inform persistent state at node=" + nodeId + " hashcode=" + hashcode);
	        
	        commitFile(filename);
		}
	}
	
	public static void updateState(long sender, int state, long proposedLeader, long proposedZxid, long logicalclock){
		String filename = "zkUpdate-" + sender;
		
		String content = "";
		content += "sender=" + sender + "\n";
		content += "state=" + state + "\n";
		content += "proposedLeader=" + proposedLeader + "\n";
		content += "proposedZxid=" + proposedZxid + "\n";
		content += "logicalclock=" + logicalclock + "\n";
		
		writePacketToFile(filename, content);
		
		LOG.info("[DMCK] State update in node: " + sender + " state: " + state + 
				" proposedLeader: " + proposedLeader + " proposedZxid: " + proposedZxid + 
				" logicalclock: " + logicalclock + " filename: " + ipcDir + "/" + filename);
		
		commitFile(filename);
	}
	
	public static void updateVotesTable(long nodeId, HashMap<Long, Vote> votesTable){
		String filename = "zkVotesTable-" + nodeId + "-" + getTimestamp();
		
		String votesTableString = "";
		int counter = 0;
		if(votesTable != null){
			for(long i : votesTable.keySet()){
				votesTableString += i + "=" + ((Vote)votesTable.get(i)).toString();
				counter++;
				if(counter != votesTable.size()){
					votesTableString += ";";
				}
			}
		}
		
		String content = "";
		content += "sender=" + nodeId + "\n";
		content += "votesTable=" + votesTableString + "\n";
		
		writePacketToFile(filename, content);
		
		LOG.info("[DMCK] State update in node: " + nodeId + " votesTable: " + votesTableString +
				" filename: " + ipcDir + "/" + filename);
		
		commitFile(filename);
	}
	
	public static void updateWorkloadAccomplishement(String value) {
		String filename = "zkWorkloadUpdate-" + value;
		
		String content = "value=" + value;
		
		writePacketToFile(filename, content);
		commitFile(filename);
	}
	
	private static void writePacketToFile(String filename, String content){
		File file = new File(ipcDir + "/new/" + filename);
		
		try {
			file.createNewFile();
			FileWriter writer = new FileWriter(file);
			writer.write(content);
			writer.flush();
			writer.close();
		} catch (Exception e){
			LOG.error("[DMCK] Error in writing state content to file.");
		}
	}
	
	private static void commitFile(String filename){
		try {
			Runtime.getRuntime().exec("mv " + ipcDir + "/new/" + filename + " " + 
	        		ipcDir + "/send/" + filename);
		} catch (Exception e){
			LOG.error("[DMCK] Error in committing file.");
		}
	}
	
	private static boolean waitForAck(String filename){
		File f = new File(ipcDir + "/ack/" + filename);
		boolean dmckResponse = false;
		
		while(!f.exists()){
			try {
				Thread.sleep(50);
				// does it need to check isExit?
			} catch (InterruptedException ie) {
				ie.printStackTrace();
			}
		}
		
		if(f.exists()) { 
			try {
				BufferedReader br = new BufferedReader(new FileReader(f));
			    for(String line; (line = br.readLine()) != null; ) {
			        if(line.contains("execute=true")){
			        	dmckResponse = true;
			        }
			    }
			} catch (Exception e) {
				LOG.error("[DMCK] Error in reading ack file.");
			}
		}
		
		try {
			Runtime.getRuntime().exec("rm " + ipcDir + "/ack/" + filename);
		} catch (Exception e){
			LOG.error("[DMCK] Error in deleting ack file.");
		}
		
		return dmckResponse;
	}
	
	private static long getHashId(long sender, long recv, int state, long leader, long zxid, long epoch){
		long prime = 31;
		long hash = 1;
		hash = prime * hash + recv;
		hash = prime * hash + sender;
		hash = prime * hash + state;
		hash = prime * hash + leader;
		hash = prime * hash + zxid;
		hash = prime * hash + epoch;
		
		return hash;
	}
	
	private static long getHashId(long sender, long recv, int msgType){
		long prime = 31;
		long hash = 1;
		hash = prime * hash + recv;
		hash = prime * hash + sender;
		hash = prime * hash + msgType;
		
		return hash;
	}
	
	private static long getHashId(long leader, long msgType, String value){
		long prime = 31;
		long hash = 1;
		hash = prime * hash + leader;
		hash = prime * hash + msgType;
		hash = prime * hash + getAsciiNumber(value);
		
		return hash;
	}
	
	private static long getHashId(long nodeId, int requestType){
		long prime = 31;
		long hash = 1;
		hash = prime * hash + nodeId;
		hash = prime * hash + requestType;
		
		return hash;
	}
	
	private static long getAsciiNumber(String s){
		long result = 0;
		long counter = 1;
		for(char c : s.toCharArray()){
			result += counter * (long) c;
			counter++;
		}
		return result;
	}
	
	private static long getTimestamp(){
		return System.currentTimeMillis() % 100000;
	}
	
	private static long calculateHashCodeForRequest(Request request){
		long result = 1;
        result = 37 * result + (int) (request.sessionId ^ (request.sessionId >>> 32));
        result = 37 * result + (int) (request.zxid ^ (request.zxid >>> 32));
        result = 37 * result + request.type;
        return result;
	}
	
	private static long calculateHashCodeForDataTree(DataTree dataTree){
		long result = 1;
        result = 7901 * result + dataTree.lastProcessedZxid;
        result = 7901 * result + dataTree.approximateDataSize();
        return result;
	}
}
