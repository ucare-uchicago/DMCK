package edu.uchicago.cs.ucare.dmck.interceptor;

import org.apache.log4j.Logger;

public class WorkloadExecutor {

	private static final Logger LOG = Logger.getLogger(WorkloadExecutor.class);
	
	private static String key;
	
	public static void main(String[] args) {
		// config read: list how many workload that we would like to execute
		if(args.length != 1){
			LOG.error("Parameters are incorrect: <key>");
			System.exit(1);
		}
		
		key = args[0];

		// initiate each workload
		Workload w1 = new Workload(2, key, "firsttry", false);
		Workload w2 = new Workload(1, key, "secondtry", true);
		
		// run each workload; keep re-executing if the write does not succeed
		w1.run();
		while(!w1.isFinished()){
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		w2.run();
	}

}
