package edu.uchicago.cs.ucare.dmck.interceptor;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.KeeperException.NodeExistsException;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs.Ids;

public class Workload implements Runnable {
	
	private static final Logger LOG = Logger.getLogger(Workload.class);
	
	private String host;
	private String key;
	private String value;
	
	private ZooKeeper zk;
	private boolean isConnected;
	private boolean mustSucceed;
	private boolean hasCreated;
	private boolean isFinished;
	private Thread t;
	
	
	public Workload(int nodeId, String key, String value, boolean mustSucceed) {
		this.host = "127.0.0.1:218" + nodeId;
		this.key = key;
		this.value = value;
		this.mustSucceed = mustSucceed;
		
		this.isConnected = false;
		this.hasCreated = false;
		this.isFinished = false;
	}
	
	public void reset() {
		if (zk != null) {
			try {
				zk.close();
			} catch (InterruptedException e) {
				LOG.error("Failed to close ZK connection.");
			}
		}
		zk = null;
		isConnected = false;
		hasCreated = false;
		isFinished = false;
	}
	
	@Override
	public void run() {
		t = new Thread(new Runnable() {
			
			@Override
			public void run() {
				LOG.info("START WORKLOAD TO " + host);
				try {
					zk = new ZooKeeper(host, 15000, new Watcher() {
						@Override
						public void process(WatchedEvent event){
							if (!hasCreated && event.getState() == KeeperState.SyncConnected) {
								LOG.info("[DMCK] Workload is Connected");
								isConnected = true;
							} else if (event.getState() == KeeperState.Disconnected) {
								LOG.info("[DMCK] Workload is Disconnected");
								isConnected = false;
							} else {
								LOG.info("[DMCK] Workload is in Unknown Connection");
							}
						}
					});
					
					LOG.info("WORKLOAD is in while !isConnected:");
					while (!isConnected) {
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}

					LOG.info("WORKLOAD enter if mustSucceed:");
					if(mustSucceed){
						while (!hasCreated){
							try {
								LOG.info("Workload create data " + value);
								zk.create(key, value.getBytes() , Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
							} catch (KeeperException e) {
								if(e instanceof NodeExistsException){
									LOG.warn("Node Exists Exception when try to create znode in ZK=" + e.getMessage());
								} else {
									e.printStackTrace();
									continue;
								}
							} catch (InterruptedException e) {
								e.printStackTrace();
								continue;
							}
							hasCreated = true;
						}
					} else {
						LOG.info("Workload create data " + value);
						zk.create(key, value.getBytes() , Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
						hasCreated = true;
					}
					zk.close();
					finish();
				} catch (IOException e) {
					LOG.error("IO Exception when try to connect to ZK.");
					e.printStackTrace();
				} catch (KeeperException e) {
					LOG.error("Keeper Exception when try to create znode in ZK. error=" + e.getMessage());
					try {
						zk.close();
						finish();
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}
				} catch (InterruptedException e) {
					LOG.error("Interrupted Exception when try to create znode in ZK.");
					try {
						zk.close();
						finish();
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}
				}
			}
		});
		
		t.start();
	}
	
	private void finish() {
		if (!isFinished) {
			notifyDMCK();
			isFinished = true;
		}
	}

	private void notifyDMCK() {
		LOG.info("Notify DMCK that it has finished a workload with value=" + value);
		InterceptionLayer.updateWorkloadAccomplishement(value);
	}
	
	public boolean isFinished() {
		return isFinished;
	}
	
}
