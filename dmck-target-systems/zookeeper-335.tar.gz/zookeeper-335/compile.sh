#!/bin/bash

ant clean && ant
